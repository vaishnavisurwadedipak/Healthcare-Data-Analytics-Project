CREATE DATABASE healthcare;
USE healthcare;

# TABLE -- Total Number of Patient
Select Count(*) from healthcare_patient;

# TABLE  -- Total Number of doctor
Select Count(*) from healthcare_doctor;

# TABLE  -- Total Number of LabResult
Select Count(*) from healthcare_lab;

# TABLE -- Total Number of Treatments
Select Count(*) from healthcare_treatment;

# TABLE  -- Total Number of visit;
Select Count(*) from healthcare_visit;


# TABLE 1 -- Total Number of Patients
SELECT COUNT(*)AS Total_Number_of_patients 
FROM healthcare_patient;


#TABLE 2 -- Total Number of Doctors
SELECT COUNT(*) AS Total_Number_of_Doctors 
FROM healthcare_doctor;


# TABLE 3 -- Total Number of Visit
SELECT COUNT(*) AS Total_Number_of_Visits 
FROM healthcare_visit;

# TABLE 4 -- Avg Age of patients
SELECT round(AVG(Age)) AS Avg_Age_of_patients 
FROM healthcare_patient;

# TABLE 5 -- Top 5 Diagnosed Condition
SELECT Diagnosis AS Top_5_Diagnosed_Condition, Count(Diagnosis) as Total_Count 
FROM healthcare_visit
GROUP BY Diagnosis
ORDER BY Total_Count DESC 
LIMIT 5;

# TABLE 6 -- Follow Up Rate
SELECT ROUND(COUNT(CASE WHEN `Follow Up Required` = "yes" THEN 1 END)/COUNT(`Visit ID`)*100,2)
AS Follow_Up_Rate
FROM healthcare_visit;


# TABLE 7 -- Treatment Cost Per Visit(Avg)
SELECT CONCAT('$ ', ROUND(AVG(`Treatment Cost`), 2)) AS Avg_Treatment_Cost
FROM healthcare_treatment;


# TABLE 8 -- Total Lab Test Conducted
SELECT COUNT(*) AS Total_Lab_Test_Conducted 
FROM healthcare_lab;

# TABLE 9 -- Percentage of Abnormal Lab Result 
SELECT CONCAT(round(COUNT(CASE WHEN `Test Result` = "Abnormal" THEN 1 END)/COUNT(`Lab Result ID`)*100,2), ' %')
AS Percentage_of_Abnormal_Lab_Result
FROM healthcare_lab;

# TABLE 10 -- Doctor Workload (Avg Patients Per Doctor)
SELECT 
    ROUND(COUNT(`Visit ID`) * 1.0 / COUNT(DISTINCT `Doctor ID`), 2) 
    AS Avg_Doctor_Workload
FROM healthcare_visit;


# TABLE 11 -- Total Revenue - 
SELECT CONCAT("Rs. ",ROUND(SUM(`Treatment Cost`) + SUM(COST),2 ))
AS TOTAL_REVENUE
FROM healthcare_treatment;

# TABLE 12 -- Total Revenue in Million
SELECT 
    CONCAT("Rs. ", ROUND((SUM(`Treatment Cost`) + SUM(COST)) / 1000000, 2), " M") 
    AS TOTAL_REVENUE_MILLION
FROM healthcare_treatment;
